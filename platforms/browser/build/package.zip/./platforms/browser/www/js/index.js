/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF AN
Y * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */



 var app = {
    // Application Constructor
    initialize: function() {
        this.CreateOrOpenDb();
        this.bindEvents();
    },
    populateDB: function(myDb) {
         myDb.transaction(function(tx) {
            //tx.executeSql('DROP TABLE Client', [], function(tx, result) {console.log("Deleted successfully: "+result);}, function(error) {alert("Error occurred while dropping the table");});
             tx.executeSql('CREATE TABLE IF NOT EXISTS Client (Id INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, QrId TEXT, Name TEXT, Surname TEXT, Division TEXT, Subdivision TEXT, Email TEXT, Mobile TEXT, AuCrDt DateTime)', [], function(tx, result) {console.log("Table created successfully");}, function(error) {alert("Error occurred while creating the table");});
             //tx.executeSql('DELETE FROM Client WHERE Id > 2', [], function(tx, result) {console.log("Deleted successfully: "+result);}, function(error) {alert("Error occurred while creating the table");});
             //tx.executeSql('INSERT INTO Client (Name, Surname, Division, Email, Mobile, AuCrDt) VALUES ("Client2", "Client2", "Graad 4", "client2@gmail.com", "000234562", DATETIME("now"))', [], function(tx, result) {console.log("Inserted successfully");}, function(error) {alert("Error occurred while creating the table");});
             //tx.executeSql('INSERT INTO Client (Name, Surname, Division, Email, Mobile, AuCrDt) VALUES ("Client3", "Client3", "Graad 5", "client3@gmail.com", "00075234234", DATETIME("now"))', [], function(tx, result) {console.log("Inserted successfully");}, function(error) {alert("Error occurred while creating the table");});
        });
    },
    CreateOrOpenDb: function() {
        console.log("CreateOrOpenDb");
        var myDb = window.openDatabase("QRPaymentDb", "1.0", "QR Payment Database", 200000); 
        this.populateDB(myDb);
        //window.sessionStorage.setItem("myDb", myDb);
    },
    loadClientData: function() {
        var myDb = window.openDatabase("QRPaymentDb", "1.0", "QR Payment Database", 200000); 
         myDb.transaction(function(tx) {
            var clientId = sessionStorage.selectedId;
            tx.executeSql('SELECT * FROM Client where id='+clientId, [], 
            function(tx, result) {
                console.log(result.rows.length + " Rows retrieved successfully");
                var len = result.rows.length;
                var client = result.rows.item(0);
                document.getElementById("updateClientQrId").value = client.QrId;
                document.getElementById("updateClientName").value = client.Name;
                document.getElementById("updateClientSurname").value = client.Surname;
                document.getElementById("updateClientEmail").value = client.Email;
                document.getElementById("updateClientMobile").value = client.Mobile;
                
                sessionStorage.oldClientName = client.Name + " " + client.Surname;

            }, 
            function(error) {alert("Error occurred while creating the table");});
        });
    },
    newPayment: function() {
        cordova.plugins.barcodeScanner.scan(
          function (result) {
            if(!result.cancelled)
            {
                if(result.format == "QR_CODE")
                {
                  alert("Barcode type is: " + result.format);
                  alert("Decoded text is: " + result.text);
                }
            }
            else
            {
              alert("You have cancelled scan");
            }
          },
          function (error) {
              alert("Scanning failed: " + error);
          }
        );
    },
    updateCurrentClient: function() {
        var myDb = window.openDatabase("QRPaymentDb", "1.0", "QR Payment Database", 200000); 
        var clientId = sessionStorage.selectedId;
        var newQrId = document.getElementById("updateClientQrId").value;
        var newName = document.getElementById("updateClientName").value;
        var newSurname = document.getElementById("updateClientSurname").value;
        var newEmail = document.getElementById("updateClientEmail").value;
        var newMobile = document.getElementById("updateClientMobile").value;
        sessionStorage.newClientName = newName + " " + newSurname;
         myDb.transaction(function(tx) {
            var clientId = sessionStorage.selectedId;
            tx.executeSql('UPDATE Client set QrId=?, Name=?, Surname=?, Email=?, Mobile=? WHERE id='+clientId, [newQrId, newName, newSurname, newEmail, newMobile], 
            function(tx, result) {
                console.log("Database updated successfully");
                $.mobile.navigate( "#listclients" );
                // var clientlink = $("#clientinlist"+clientId);
                // if (clientlink && clientlink[0]) {
                //     clientlink[0].innerHTML = clientlink[0].innerHTML.replace(sessionStorage.oldClientName,sessionStorage.newClientName);
                // }
                app.loadData();
            }, 
            function(error) {alert("Error occurred while updating Client table");});
        });
    },
    // guid: function() {
    //     return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
    //         var r = Math.random()*16|0, v = c == 'x' ? r : (r&0x3|0x8);
    //         return v.toString(16);
    //     });
    // },
    saveNewClient: function() {
        var myDb = window.openDatabase("QRPaymentDb", "1.0", "QR Payment Database", 200000); 
        var clientId = sessionStorage.selectedId;
        var newDivision = document.getElementById("newClientDivision").value;
        var newName = document.getElementById("newClientName").value;
        var newSurname = document.getElementById("newClientSurname").value;
        var newEmail = document.getElementById("newClientEmail").value;
        var newMobile = document.getElementById("newClientMobile").value;
        var newQrId = document.getElementById("newClientQrId").value;
        //var newQrId = 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {var r = Math.random()*16|0,v=c=='x'?r:r&0x3|0x8;return v.toString(16);});
        // Clean data on page

        
         myDb.transaction(function(tx) {
            var clientId = sessionStorage.selectedId;
            tx.executeSql('INSERT INTO Client (QrId, Name, Surname, Division, Email, Mobile, AuCrDt) VALUES (?,?,?,?,?,?, DATETIME("now"))', [newQrId, newName, newSurname, newDivision, newEmail, newMobile], 
            function(tx, result) {
                console.log("Record inserted successfully");
                $.mobile.navigate( "#listclients" );
                document.getElementById("newClientName").value = "";
                document.getElementById("newClientSurname").value = "";
                document.getElementById("newClientEmail").value = "";
                document.getElementById("newClientMobile").value = "";
                app.loadData();
            }, 
            function(error) {alert("Error occurred while inserting into Client table: "+error.message);});
        });
    },
    listclientsOnPageCreate: function() {
        
        app.loadData();
    },
    // loadDataNew: function() {
    //     var myDb = window.openDatabase("QRPaymentDb", "1.0", "QR Payment Database", 200000); 
    //      myDb.transaction(function(tx) {
    //         tx.executeSql('SELECT * FROM Client ORDER BY Division, subdivision, Name, Surname', [], 
    //         function(tx, result) {
    //             console.log(result.rows.length + " Rows retrieved successfully");
    //             var len = result.rows.length, i;
    //             var currentDivision="";
    //             var clientlist = {
    //                 clients: [][]
    //             };
    //             var divisionlist = [];

    //             for (i = 0; i < len; i++){
    //                 var client = result.rows.item(i);
    //                 if (client.Division != currentDivision) {                        
    //                     currentDivision = client.Division;
    //                     divisionlist.clear();
    //                 }
    //                 clientlist.clients.push({
    //                     "name"    : client.Name,
    //                     "surname" : client.Surname
    //                 });
    //             };
    //             var template = $("#clienttemplate").html();
    //             var output = Mustache.render(template, clientlist);
    //             $('#clientcontainer').append(output);
                
    //         }, 
    //         function(error) {alert("Error occurred while creating the table");});
    //     });
    // },
    loadData: function() {
        // var childList = [];
        // //var myDb = window.sessionStorage.getItem("myDb");
        // $('#clientListContent').children().each(function(){
        //     childList.push($(this));
        // });

        var myDb = window.openDatabase("QRPaymentDb", "1.0", "QR Payment Database", 200000); 
         myDb.transaction(function(tx) {
            tx.executeSql('SELECT * FROM Client ORDER BY Division, subdivision, Name, Surname', [], 
            function(tx, result) {
                console.log(result.rows.length + " Rows retrieved successfully");
                var node = document.getElementById('clientListContent');
                while (node.hasChildNodes()) {
                    node.removeChild(node.firstChild);
                }
                //$("#clientcontainer").html = "<div data-role='collapsible-set' data-content-theme='d' id='clientListContent'></div>";
                var len = result.rows.length, i;
                var currentDivision="";
                var currentSubdivision="";
                var firstDivision = true;
                var firstClient = true;
                var appendStr = "";
                for (i = 0; i < len; i++){
                    var client = result.rows.item(i);
                    if (client.Division != currentDivision) {                        
                        currentDivision = client.Division;
                        firstClient = true;
                        if (firstDivision) {
                            // $("#clientListContent").append("<div data-role='collapsible'><h4>"+currentDivision+"</h4><ul id='clientlv' data-role='listview' data-inset='true'>");
                            appendStr += "<div data-role='collapsible' id='division" + client.Id + "'><h4>"+currentDivision+"</h4><ul id='clientlv" + i + "' data-role='listview' data-inset='true'>";
                            firstDivision=false;
                        }
                        else {
                            appendStr += "</ul></div><div data-role='collapsible' id='division" + client.Id + "'><h4>"+currentDivision+"</h4><ul id='clientlv" + i + "' data-role='listview' data-inset='true'>";
                        }
                    }
                    appendStr += "<li><a id='clientinlist"+client.Id+"'>"+client.Name + " " + client.Surname + "</a></li>";
                    // appendStr += "<li><a href='#updateclient'>"+client.Name + " " + client.Surname + "</a></li>";
                    //$("#clientListContent").append("<tr><td>"+result.rows.item(i).Id+"</td><td>"+result.rows.item(i).Name+"</td><td>"+result.rows.item(i).Surname+"</td></tr>");
                };
                appendStr+="</ul></div>";
                //var div = document.getElementById('clientListContent');
                //console.log("Append string:" + appendStr);
                var node = $("#clientListContent");
                node.innerHTML="";
                $("#clientListContent").append( appendStr ).collapsibleset('refresh');
                $('#listclients').trigger('create');
                var clientlinks = $('*[id^="clientinlist"]');
                var clientSize = clientlinks.length;
                $('#clientListContent').children().each(function(){
                //clientlinks.each(function(){
                //for (var i = 0; i < clientSize; i++) {
                    var anchor = $(this).find('a');
                    //var anchor = clientlinks[i];
                    if(anchor)
                    {
                        //if (anchor.attr('id').indexOf('client') > -1) {
                            anchor.click(function(){
                                // save the selected id to the session storage and retrieve it in the next page
                                //sessionStorage.selectedId=anchor.attr('id');
                                if (this.id.indexOf('clientinlist') > -1) {
                                    sessionStorage.selectedId=this.id.replace("clientinlist","");
                                    app.loadClientData();
                                    $.mobile.navigate( "#updateclient" );
                                }
                            });
                        //}
                    }
                });
                //console.log("div content:" + div.innerc)
                //$("#clientListContent").append(appendStr);
                //$('[clientListContent]').collapsibleset().trigger('create');
            }, 
            function(error) {alert("Error occurred while creating the table");});
        });
        // myDb.transaction(function(tx) {
        //     tx.executeSql('SELECT * FROM Client', [], function (tx, results) {
        //         var len = results.rows.length, i;
        //         //$("#rowCount").append(len);
        //         for (i = 0; i < len; i++){
        //             $("#clientListContent").append("<tr><td>"+results.rows.item(i).Id+"</td><td>"+results.rows.item(i).Name+"</td><td>"+results.rows.item(i).Surname+"</td></tr>");
        //         }
        //     }, null);
        // }, [], function(tx, result) {console.log("Data retrieved successfully");}, function(error) {alert("Error occurred while fetching data");});
    },
    bindEvents: function() {
        sessionStorage.firstTimeRun=true;
        $(document).on("pagecreate","#listclients",function(event){app.listclientsOnPageCreate();});
        $(document).on("pagecreate","#updateclient",function(event){app.loadClientData();});
        $(document).on("pagecreate","#newpayment",function(event){app.newPayment();});
        $(document).on("click","#BtnUpdateClient",function(event){app.updateCurrentClient();});
        $(document).on("click","#BtnSaveNewClient",function(event){app.saveNewClient();});
        // $(document).on("pagecreate","#pagetwo",function(event){
        //     $.(":jqmData(role='my-plugin')").myPlugin();
        // });
        // document.addEventListener('deviceready', this.onDeviceReady, false);
        // $('#add-client-button').click(function() {
        //     $.mobile.changePage($('#addclient'));
        //     //this.goToPage($('#addclient'));
        // });

        // $('#client-list').click(function() {
        //     $.mobile.changePage($('#addclient'));
        // });
    }
};

